import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class AlertPage extends StatelessWidget {
  showMyAlert(BuildContext context) {
    showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            title: Text("Delmiza titulo de dialog"),
            backgroundColor: Colors.white,
            elevation: 50.0,
            content: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Image.asset(
                  "assets/images/chekccc.png",
                  height: 90.0,
                ),
                SizedBox(
                  height: 10.0,
                ),
                Text(
                  "Fluterr alert",
                  style: GoogleFonts.poppins(
                    fontSize: 18,
                    fontWeight: FontWeight.w500,
                    color: Colors.black.withOpacity(0.5),
                  ),
                ),
                Text(
                  " Dia 29 de octubre del 2024 semana 10 de la clase de desarrollo de aplicaciones moviles ",
                  style: GoogleFonts.poppins(
                    color: Colors.black.withOpacity(0.8),
                  ),
                  textAlign: TextAlign.justify,
                ),
              ],
            ),
            shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(20.0)),
            actions: [
              ElevatedButton(
                  onPressed: () {
                    Navigator.pop(context);
                  },
                  child: Text("Aceptar")),
              Text("boton"),
              TextButton(
                  onPressed: () {
                    Navigator.pop(context);
                  },
                  child: Text("Cerrar")),
            ],
          );
        });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.deepPurpleAccent,
      body: Center(
        child: ElevatedButton(
          style: ElevatedButton.styleFrom(
              //primary: Colors.orange,
              ),
          onPressed: () {
            showMyAlert(context);
          },
          child: Text("botton de alerta"),
        ),
      ),
    );
  }
}
